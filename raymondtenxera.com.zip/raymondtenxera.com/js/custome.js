/* Demo Scripts for Bootstrap Carousel and Animate.css article
 * on SitePoint by Maria Antonietta Perna
 */
(function($) {
    //Function to animate slider captions
    function doAnimations(elems) {
        //Cache the animationend event in a variable
        var animEndEv = "webkitAnimationEnd animationend";

        elems.each(function() {
            var $this = $(this),
                $animationType = $this.data("animation");
            $this.addClass($animationType).one(animEndEv, function() {
                $this.removeClass($animationType);
            });
        });
    }

    //Variables on page load
    var $myCarousel = $("#home-carousel"),
        $firstAnimatingElems = $myCarousel
        .find(".item:first")
        .find("[data-animation ^= 'animated']");

    //Initialize carousel
    $myCarousel.carousel({
        interval: 6000,
        cycle: true,
        pause: "false",
    });

    //Animate captions in first slide on page load
    doAnimations($firstAnimatingElems);

    //Other slides to be animated on carousel slide event
    $myCarousel.on("slide.bs.carousel", function(e) {
        var $animatingElems = $(e.relatedTarget).find(
            "[data-animation ^= 'animated']"
        );

        doAnimations($animatingElems);
    });
    // End of bootsrap Carousel--------------------

    //Menu Smooth Scroll
    $(".m-link").on("click", function(event) {
        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
            // Prevent default anchor click behavior
            event.preventDefault();

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

            $("html, body").animate({
                    scrollTop: $(hash).offset().top,
                },
                800,
                function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                }
            );
        } // End if
    });

    //carousel------

    $(".pillar-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
            },
            768: {
                items: 3,
                //autoplay: false,
                //loop: false
            },
        },
    });
    $(".spe-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 0,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
            },
            768: {
                items: 2,
            },
        },
    });
    $(".floor-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 15,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
                autoplay: true,
                loop: true,
            },
            768: {
                items: 2,
                autoplay: false,
                loop: false,
            },
        },
    });
    $(".iso-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 15,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
                autoplay: true,
                loop: true,
            },
            768: {
                items: 3,
                autoplay: false,
                loop: false,
            },
        },
    });
    $(".isoo-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 15,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
                autoplay: true,
                loop: true,
            },
            768: {
                items: 3,
                autoplay: false,
                loop: false,
            },
        },
    });
    $(".gall-carousel").owlCarousel({
        items: 3,
        loop: true,
        margin: 15,
        autoplay: true,
        smartSpeed: 1500,
        autoplayTimeout: 7000,
        autoplayHoverPause: true,
        nav: true,
        dots: false,
        navText: ["<img src='images/left.png'>", "<img src='images/right.png'>"],
        responsive: {
            0: {
                items: 1,
            },
            768: {
                items: 3,
            },
        },
    });

    //Fancybox ---------

    $('[data-fancybox="pillar"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });
    $('[data-fancybox="loc"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });

    $('[data-fancybox="google"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });

    $('[data-fancybox="view360"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });

    $('[data-fancybox="video"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });
    $('[data-fancybox="floor"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });
    $('[data-fancybox="iso"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });
    $('[data-fancybox="master"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });
    $('[data-fancybox="gall"]').fancybox({
        //slide effect- zoom-in-out
        transitionEffect: "slide",
        loop: true,

        buttons: [
            //'slideShow',
            //'share',
            "zoom",
            "fullScreen",
            "close",
            //'download'
        ],
        thumbs: {
            autoStart: false,
        },
    });

    $(".i-am").click(function() {
        $("#interested").modal("show");
    });
    $(".get-offer").click(function() {
        $('#get-offer').modal('show');
    });
    $(".interested").click(function() {
        $("#interested").modal("show");
    });
    $(".price-click").click(function() {
        $("#pricepop").modal("show");
    });

    $(".floor-click").click(function() {
        $("#floorplan").modal("show");
    });

    //AOS Initialization
    AOS.init({
        //easing: 'ease-in-out-sine'
        easing: "ease-out-back",
    });

    $(window).load(function() {
        $("#pageloader").fadeOut();
    });

    // Jquery Mobile Validation
    jQuery.validator.addMethod(
        "country",
        function(value, element) {
            return this.optional(element) || /^[^+]/.test(value);
        },
        "Enter Number Without Country Code"
    );
    jQuery.validator.addMethod(
        "number",
        function(value, element) {
            return this.optional(element) || value.match(/^[1-9][0-9]*$/);
        },
        "Please enter the number without beginning with '0'"
    );
    jQuery.validator.addMethod(
        "mobile",
        function(value, element) {
            return this.optional(element) || $(element).intlTelInput("isValidNumber");
        },
        "Please enter a valid mobile number"
    );
    jQuery.validator.addMethod(
        "alphabets",
        function(value, element) {
            return this.optional(element) || /^[a-zA-Z ]*$/.test(value);
        },
        "Please enter Alphabets only"
    );
    jQuery.validator.addMethod(
        "email",
        function(value, element) {
            return (
                this.optional(element) ||
                /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
                    value
                )
            );
        },
        "Please enter a valid email address."
    );
    jQuery.validator.addMethod(
        "valueNotEquals",
        function(value, element, arg) {
            return arg !== value;
        },
        "Value must not equal arg."
    );
    if ($("#offer-now").length > 0) {
        $("#offer-now").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#enquire-now").length > 0) {
        $("#enquire-now").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#contact-form").length > 0) {
        $("#contact-form").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }

    if ($("#floor-now").length > 0) {
        $("#floor-now").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }

    if ($("#price-popup").length > 0) {
        $("#price-popup").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#main-popup").length > 0) {
        $("#main-popup").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#brochureDownloadForm").length > 0) {
        $("#brochureDownloadForm").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#projectform").length > 0) {
        $("#projectform").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
    if ($("#reg-form").length > 0) {
        $("#reg-form").validate({
            rules: {
                fname: {
                    required: true,
                    maxlength: 100,
                },
                mobile: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email: {
                    required: true,
                    email: true,
                },
                termcheckbox: {
                    required: true,
                },
            },
            messages: {
                fname: {
                    required: "Enter Your Name",
                },
                mobile: {
                    required: "Enter Your Number",
                },
                email: {
                    required: "Enter Your Email",
                },
                termcheckbox: {
                    required: "Select Checkbox",
                },
            },
        });
    }
})(jQuery);