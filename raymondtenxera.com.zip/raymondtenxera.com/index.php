<!doctype html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Raymond TenX Era - 2 Bed Homes at Thane</title>
    <link rel="icon" href="images/fav-icon.webp" type="image/webp" sizes="16x16">
    <!-- Header -->


    <!-- Bootstrap CSS -->
    <!-- Latest compiled and minified bootstrap CSS -->
    <link rel="stylesheet" href="css/plugin.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

    <!--End Menu css files-->
    <link rel="stylesheet" href="css/style.css">
    <!--    <link rel="stylesheet" href="css/css2.css">-->
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fonts/flaticon.css">

    <link rel="stylesheet" type="text/css" href="slick/slick.css">
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css">


</head>

<body>

<header id="home">
    <nav class="navbar navbar-default" id="hide-menu">
        <div class="container-fluid pdm-0">
            <!-- Brand and toggle get grouped for better mobile display -->

            <div class="col-md-2 hidden-xs">
                <div class="navbar-header">
                    <a class="navbar-brand" href="javascript:void(0);">
                            <img src="images/logo-1.jpg">
                        </a>
                </div>
            </div>
            <div class="col-md-10 col-xs-12 pdm-0">
                <div class="navbar-header visible-xs">
                    <button type="button" class="navbar-toggle collapsed open-menu">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    <a class="navbar-brand" href="javascript:void(0);">
                            <img src="images/logo-1.jpg">
                            <!-- <img class="visible-xs nav-logo" src="images/logo.webp"> -->
                        </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li><a href="#home" class="m-link">Home</a></li> -->
                        <li><a href="#about" class="m-link">About Ten X Era</a></li>
                        <li><a href="#configuration" class="m-link">Configuration</a></li>
                        <li><a href="#location" class="m-link">Location</a></li>
                        <li><a href="#amenities" class="m-link">Amenities</a></li>
                        <li><a href="#progallery" class="m-link">Gallery</a></li>
                        <li><a href="#aboutus" class="m-link">About us</a></li>
                        <li><a href="#contactus" class="m-link">Contact Us</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>



        </div>
        <!-- /.container-fluid -->
    </nav>
</header>
<!--Mobile Menu-->
<div id="myNav" class="menu-overlay">
    <a href="javascript:void(0)" class="closebtn close-menu">&times;</a>
    <div class="menu-overlay-content">
        <a href="#home" class="close-menu m-link"><span>Home</span></a>
        <a href="#about" class="close-menu m-link"><span>About TenXEra</span></a>
        <a href="#configuration" class="close-menu m-link"><span>Configuration</span></a>
        <a href="#location" class="close-menu m-link"><span>Location</span></a>
        <a href="#amenities" class="close-menu m-link"><span>Amenities</span></a>
        <a href="#progallery" class="close-menu m-link"><span>Gallery</span></a>
        <a href="#aboutus" class="close-menu m-link"><span>About Us</span></a>
        <a href="#contactus" class="close-menu m-link"><span>Contact Us</span></a>
    </div>
</div>
<!--Mobile Menu-->

<section class="mobile_form hidden">
    <div class="col-md-12">
        <h3>Express Your Interest</h3>
        <p>Please Enter Your Details To Know More About Raymond TenX Era </p>
    </div>
    <form id="register_form" action="thank-you.php" name="register_form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('register_form');">
        <div class="form-group col-md-12">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                </div>
                <input id="mainpopup-fname" type="text" class="form-control" name="fname" placeholder="Name">
                <input type="hidden" name="source" value="Register Form Mobile">
            </div>
            <label for="mainpopup-fname" class="error"></label>
        </div>
        <div class="form-group col-md-12">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                </div>
                <input id="mainpopup-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
            </div>
            <label for="mainpopup-mobile" class="error"></label>
        </div>
        <div class="form-group col-md-12">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                </div>
                <input id="mainpopup-email" type="email" class="form-control" name="email" placeholder="Email">
            </div>
            <label for="mainpopup-email" class="error"></label>
        </div>
        <div class="col-md-12">
            <div class="check-input">
                <div class="row">
                    <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                    <p class="form-terms">
                        By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                    </p>
                </div>
            </div>
            <label for="termcheckbox" class="error"></label>
        </div>

        <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
    </form>
</section>

<div id="home-carousel" class="carousel slide carousel-fade" data-ride="carousel">

    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="images/slider/w8.jpg" alt="" class="slide hidden-xs">
            <img src="images/slider/m8.jpg" alt="" class="slide visible-xs">
        </div>
        <div class="item">
            <img src="images/slider/w9.jpg" alt="" class="slide hidden-xs">
            <img src="images/slider/m9.jpg" alt="" class="slide visible-xs">
        </div>
        <div class="item">
            <img src="images/slider/w10.jpg" alt="" class="slide hidden-xs">
            <img src="images/slider/m10.jpg" alt="" class="slide visible-xs">
        </div>
        <!-- <div class="item">
                <img src="images/slider/w11.jpg" alt="" class="slide hidden-xs">
                <img src="images/slider/m11.jpg" alt="" class="slide visible-xs">
            </div> -->

    </div>
    <a class="left carousel-control" href="#home-carousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
    <a class="right carousel-control" href="#home-carousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
</div>
<!-- <div class="col-md-12 pd0">
        <img data-animation="animated fadeInUp" class="anim-delay1 slide1-item1" src="images/slider/Banner1-aa.webp">
    </div>
    <div class="col-md-6 pd0">
        <img data-animation="animated fadeInDown" class="anim-delay1 slide1-item2" src="images/slider/Banner1-b.webp">
    </div> -->

<!-- <div class="grey-halfpatch greybg"></div> -->

<section id="overview" class="global-sec sec-pillar" style="display:none;">
    <div class="container">
        <div class="section-head clearfix" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
            <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                <!-- <small class="wt-small-title">Experience the</small> -->
                <h2 class="m-b5">Overview</h2>
            </div>
            <div class="title-right-detail">
                <p></p>
            </div>
        </div>
        <p data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
            It is a special feeling to be ahead of the crowd. The recent feat of delivering two years before the RERA deadline has only reaffirmed this. Our next follows Raymond&#39;s legacy of excellence and craftsmanship. It builds not only in the sense of lifestyle
            upgrades but also on how far ahead they are in terms of modern living. It starts with a dream location. Close to the metro and highway, neighbour to an international-level school and a world- class mall at your doorstep. The spell gets deeper
            with every detail you discover. It is not just about how things look but about how they make you feel. Everything here is miles ahead, and It&#39;s time for the rest to play catch up.
        </p>
    </div>


</section>
<!-- <div class="below-halfpatch"></div> -->

<!-- ***************************************** Offer Start *********************************** -->
<section id="offers" style="display: none;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                    <!-- <span text-transform: uppercase;font-weight: bold;"> </span> -->
                    <h2 class="m-b5">
                        Fantastic Offers*
                    </h2>
                </div>
            </div>
            <!-- ******************************** SLider Offer ********************* -->
            <!-- <div class="col-md-12">
                    <div class="owl-carousel owl-theme iso-carousel">
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/tourism.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>International <br>Trip</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/bank.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>Subvention <br>Scheme</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/loan.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>Rent Back <br>Offer</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/real-estate.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>Spot <br>Offer</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/draw.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>Lucky<br> Draw</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/gift.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>Raymond Home <br>Gift</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="key_img">
                                <div class="key-images">
                                    <img src="images/ame/happiness.png" alt="">
                                </div>
                                <div class="key-desc">
                                    <p>0 <br>SDR</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

            <div class="col-md-12 hidden-xs">
                <div class="row">
                    <div class="col-md-12 col-md-offset-1">
                        <div class="col-md-3">
                            <div class="offer-container">
                                <div class="images-wrapper">
                                    <img src="images/ame/spot.png" alt="">
                                </div>
                                <div class="key-desc pt-0">
                                    <p>Spot Offer</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="offer-container">
                                <div class="images-wrapper">
                                    <img src="images/ame/lucky1.png" alt="">
                                </div>
                                <div class="key-desc pt-0">
                                    <p>Lucky Draw</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="offer-container">
                                <div class="images-wrapper">
                                    <img src="images/ame/smile1.png" alt="">
                                </div>
                                <div class="key-desc pt-0">
                                    <p>0 SDR</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/trip.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>International <br>Trip</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/bank1.png" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Subvention <br>Scheme</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/rent1.png" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Rent Back <br>Offer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/gift1.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>Raymond Home <br>Gift</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-12 visible-xs">
                <div class="row">

                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/spot.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>Spot Offer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/lucky1.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>Lucky Draw</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/smile1.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>0 SDR</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/trip.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>International <br>Trip</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/bank1.png" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Subvention <br>Scheme</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/rent1.png" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Rent Back <br>Offer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6 col-xs-offset-3">
                        <div class="offer-container">
                            <div class="images-wrapper">
                                <img src="images/ame/gift1.png" alt="">
                            </div>
                            <div class="key-desc pt-0">
                                <p>Raymond Home <br>Gift</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>



            <!-- <div class="col-md-3 col-xs-6">
                    <div class="offer-container">
                        <div class="images-wrapper">
                            <img src="images/ame/trip.png" alt="">
                        </div>
                        <div class="key-desc pt-0">
                            <p>International <br>Trip</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-xs-6">
                    <div class="offer-container">
                        <div class="images-wrapper">
                            <img src="images/ame/bank1.png" alt="">
                        </div>
                        <div class="key-desc">
                            <p>Subvention <br>Scheme</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-xs-6">
                    <div class="offer-container">
                        <div class="images-wrapper">
                            <img src="images/ame/rent1.png" alt="">
                        </div>
                        <div class="key-desc">
                            <p>Rent Back <br>Offer</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-xs-6">
                    <div class="offer-container">
                        <div class="images-wrapper">
                            <img src="images/ame/gift1.png" alt="">
                        </div>
                        <div class="key-desc pt-0">
                            <p>Raymond Home <br>Gift</p>
                        </div>
                    </div>
                </div> -->

            <div class="col-md-12">
                <div class="btn-wrapper">
                    <button class="get-offer">Get Offers</button>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn-condition visible-xs" data-toggle="modal" data-target="#myModal">
                            T & C Apply*
                        </button>

                    <button type="button" class="btn-condition hidden-xs" data-toggle="modal" data-target="#myModal">
                            Terms & Conditions Apply*
                        </button>

                </div>
            </div>


            <div class="col-md-12">
                <div class="condition">
                    <!-- Button trigger modal -->
                    <!-- <button type="button" class="btn-condition hidden-xs" data-toggle="modal" data-target="#myModal">
                            Terms & Conditions Apply*
                        </button> -->

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content" style="background-color: #000 !important">
                                <div class="modal-header" style="background-color: #fff !important">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color:#000;font-size: 30px;">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Disclaimer</h4>
                                </div>
                                <div class="modal-body">
                                    <ul class="dis">
                                        <li>
                                            The home fest will be commencing from 14th June 2024 to 30th June, 2024.
                                        </li>
                                        <li>
                                            Any booking done after 30th June will not be considered for the following offers.
                                        </li>
                                        <li>
                                            The following offers are applicable for Ten X Era: The purchaser will be entitled to any 1 offer out of following 3 offers.
                                        </li>
                                    </ul>
                                    <!-- <p>The home fest will be commencing from 14th June 2024 to 23rd June, 2024.</p>
                                        <p>Any booking done after 23rd June will not be considered for the following offers.</p>
                                        <p>The following offers are applicable for Ten X Era: The purchaser will be entitled to any 1 offer out of following 3 offers.</p> -->
                                    <ol class="disclaimerPoints">
                                        <li>
                                            Subvention Scheme: This offer is applicable for Tower A, B & C of TEN X Era till January 2025.
                                        </li>
                                        <li>
                                            Rent Back: Rent amount will be calculated after successful registration of the unit. The rent amount may vary on the basis of unit and Project. The decision of the amount of rent calculated by the Prompter shall be final and binding upon the purchasers.
                                            The rent shall be paid for the period 12 months from the date of registration of the apartment.
                                        </li>
                                        <li>
                                            International Trip Voucher: Trip voucher worth Rs.4 Lakh will be given on successful booking and registration or else can be availed as upfront discount.
                                        </li>
                                    </ol>
                                    <p style="margin-top:20px">List of other offers for Homefest (14th June 2024 to 30th June, 2024)</p>
                                    <ol class="disclaimerPoints">
                                        <li>
                                            Zero Stamp Duty.
                                        </li>
                                        <li>
                                            No Floor rise. (Not applicable for Ten X Era)
                                        </li>
                                        <li>
                                            Spot offer: upto Rs.1 Lakh.
                                        </li>
                                        <li>
                                            Spin the wheel: All the bookings made under home fest campaign are eligible to spin the lucky draw wheel to avail an additional discount of upto Rs.50,000/-
                                        </li>
                                        <li>
                                            Raymond Home Furnishing: Furnishing gift worth of Rs.30,000/- will be given.
                                        </li>
                                    </ol>
                                </div>
                                <!-- <div class="modal-footer">
                                        <button type="button" class="btn btn-default"
                                            data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Save changes</button>
                                    </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ***************************** Get Offer Button ************************** -->


            <div class="modal fade in" tabindex="-1" role="dialog" id="get-offer" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <img src="images/logo-1.jpg" alt="Life Republic icon2">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            <h3>Get Offers</h3>
                            <p>Please Enter Your Details To Know More About Offer</p>
                            <form id="offer-now" action="thank-you.php" name="offer-now" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('offer-now');">
                                <div class="form-group col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                        </div>
                                        <input id="mainpopup-fname" type="text" class="form-control" name="fname" placeholder="Name">
                                        <input type="hidden" name="source" value="Get Offers">
                                    </div>
                                    <label for="mainpopup-fname" class="error"></label>
                                </div>
                                <div class="form-group col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                        </div>
                                        <input id="mainpopup-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                                    </div>
                                    <label for="mainpopup-mobile" class="error"></label>
                                </div>
                                <div class="form-group col-md-12">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                        </div>
                                        <input id="mainpopup-email" type="email" class="form-control" name="email" placeholder="Email">
                                    </div>
                                    <label for="mainpopup-email" class="error"></label>
                                </div>
                                <div class="col-md-12">
                                    <div class="check-input">
                                        <div class="row">
                                            <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                            <p class="form-terms">
                                                By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                            </p>
                                        </div>
                                    </div>
                                    <label for="termcheckbox" class="error"></label>
                                </div>
                                <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

    </div>
    </div>
</section>
<!-- ***************************************** Offer End *********************************** -->

<section class="section_dev" id="about">
    <div class="container">
        <div class="row">

            <div class="col-md-12 col-sm-12">
                <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                    <!-- <span text-transform: uppercase;font-weight: bold;"> </span> -->
                    <h2 class="m-b5">
                        <span style="font-size: 20px;">ABOUT</span><br>Ten X Era – A Development Miles Ahead of Time
                    </h2>
                </div>

                <div class="over-para" style="display:inline-block;">
                    <p>
                        At Raymond Realty, staying ahead is a quest. To constantly push the boundaries. To be on the cutting edge of style. To be the trendsetter. Experience what it is like to live miles ahead of time. Experience the new Era in living with Ten X Era. Ten X Era
                        offers a mix of intelligent design, smart use of space, and a futuristic lifestyle. Ten X Era is located next to Viviana Mall and closer to nearly every aspect of today’s fast-paced life.
                    </p>
                </div>
            </div>
            <!-- <div class="col-md-4 col-sm-12">
                    <div class="up-form aos-init aos-animate  hidden-xs" data-aos="fade-left"
                        data-aos-anchor="#example-anchor" data-aos-offset="500" data-aos-duration="2000">
                        <p class="reg-title">REGISTER YOUR INTEREST</p>
                        <form id="reg-form" action="thank-you.php" name="reg-form" method="POST"
                            onsubmit="return save_landing_pageinfo('reg-form');" novalidate="novalidate">
                            <div class="form-group col-md-12 pd">
                                <div class="input-group" style="display: block">
                                    <input type="text" class="form-control" name="fname"
                                        placeholder="Please Enter Your Full Name">
                                    <input type="hidden" name="source" value="Register form Desktop" id="source">
                                </div>
                                <label for="fname" generated="true" class="error"></label>
                            </div>

                            <div class="form-group col-md-12 ">
                                <div class="input-group" style="display: block">
                                    <input type="number" id="mobile" placeholder="Please Enter Your Mobile No.*"
                                        name="mobile" required="">
                                </div>
                                <span id="errorMessage" style="display:none;color:red;font-weight:bold">Please enter
                                    correct
                                    number of
                                    digits</span>
                                <label for="mobile" generated="true" class="error"></label>
                            </div>
                            <div class="form-group col-md-12 pd">
                                <div class="input-group" style="display: block">
                                    <input type="email" class="form-control" name="email"
                                        placeholder="Please Enter Your Email">
                                </div>
                                <label for="email" generated="true" class="error"></label>
                            </div>

                            <button type="submit" class="btn btn-default price-btn" value="proceed">SUBMIT</button>
                        </form>

                    </div>
                </div> -->
        </div>

    </div>
</section>

<section class="section_heading">
    <div class="container">
        <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
            <!-- <span style="font-size: 20px;text-transform: uppercase;font-weight: bold;">About</span> -->
            <h2 class="m-b5">Key Features</h2>
            <!-- <h2 class="m-b5">
                    <span style="font-size: 20px;">Key</span><br>Features</h2> -->
        </div>
        <!-- <div class="wt-tilte-main features">
                <h2 class="m-b5">Key Features</h2>
            </div> -->
        <!-- <div class="row hidden-xs">
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f1.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>3.74 Acres gated development</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f2.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>38 Storey Three towers</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f3.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>26,500 sq.ft Clubhouse</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f4.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>40+ Indoor & Outdoor amenities</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f5.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>Efficiently Planned 2 & 3 Bed Vaastu Compatiable Homes</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="key_img">
                        <div class="key-images">
                            <img src="images/f6.webp" alt="">
                        </div>
                        <div class="key-desc">
                            <p>Centrally Located Next To Viviana Mall</p>
                        </div>
                    </div>
                </div>
            </div> -->
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel owl-theme iso-carousel">
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f1.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>3.74 Acres gated <br>development</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f2.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>38 Storey <br>Three towers</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f3.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>26,500 sq.ft <br>Clubhouse</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f4.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>40+ Indoor & Outdoor <br>amenities</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f5.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Efficiently Planned 2 & 3 Bed <br>Vaastu Compatiable Homes</p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="key_img">
                            <div class="key-images">
                                <img src="images/f6.webp" alt="">
                            </div>
                            <div class="key-desc">
                                <p>Centrally Located Next To <br>Viviana Mall</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- <div class="over-para" style="padding-top:50px;">
                <ul>
                    <li>3.74 Acres gated development</li>
                    <li>Three 38-storey towers</li>
                    <li>26,500 sq.ft Clubhouse</li>
                    <li>40+ indoor & outdoor amenities</li>
                    <li>Efficiently planned 2 & 3 bed Vaastu compatible homes</li>
                    <li>Centrally located, next to Viviana Mall</li>
                </ul>
            </div> -->
    </div>
</section>

<section id="configuration" class="global-sec global_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                    <h2 class="m-b5"><span style="font-size:20px">Project</span><br>Configuration</h2>
                </div>

                <!--  -->
                <div style="text-align: center;" class="">
                    <table class="conf-table foo tbl" style="text-align: center; margin: auto; width: 100%;" border="0">
                        <thead>
                            <tr>

                                <th class="her">
                                    <h3>Flat Type</h3>
                                </th>
                                <th class="her">
                                    <h3>Carpet Area</h3>
                                </th>

                                <th class="her">
                                    <h3>Price</h3>
                                </th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td scope="row" class="her1 ">2 BHK CREST </td>
                                <td scope="row" class="her1 ">595 SQ.FT</td>

                                <td class="her1 cursor click_here"><a href="javascript:void(0)" class="price-click">Click Here</a>
                                </td>
                            </tr>
                            <tr>
                                <td scope="row" class="her1 ">2 BHK APEX </td>
                                <td scope="row" class="her1 ">685 SQ.FT</td>

                                <td class="her1 cursor click_here"><a href="javascript:void(0)" class="price-click">Click Here</a>
                                </td>
                            </tr>
                            <tr>
                                <td scope="row" class="her1 ">3 BHK ETERNA</td>
                                <td scope="row" class="her1 ">790 SQ.FT</td>

                                <td class="her1 cursor click_here"><a href="javascript:void(0)" class="price-click">Click Here</a>
                                </td>
                            </tr>
                            <tr>
                                <td scope="row" class="her1 ">3 BHK ELITE</td>
                                <td scope="row" class="her1 ">855 SQ.FT</td>

                                <td class="her1 cursor click_here"><a href="javascript:void(0)" class="price-click">Click Here</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>

    <!-- <div class=" clearfix section_config">
            <div class="wt-tilte-main_1">
                <small class="wt-small-title">Project</small>
                <h2 class="m-b5 text-center"> Configuration</h2>
                <div class="head-line1 position-relative"></div>
            </div>

        </div> -->
    <div class="container" style="display:none;">

        <div class="row mr0">
            <div class="col-md-3" data-aos="fade-right" data-aos-delay="400" data-aos-duration="1000">

                <div class="priceshadow">
                    <div class="pricingTable">
                        <div class="pricingTable-header">
                            <h3 class="title">2 BHK Crest</h3>
                        </div>
                        <div class="price-value">
                            <h3 class="title1">rera carpet area :</h3>
                            <span class="amount">595 SQ.FT</span>

                            <div class="line"></div>
                            <!-- <h3 class="title1">balcony area :</h3>
                                <span class="amount">20 SQ.FT</span>
                                <div class="line"></div> -->
                            <!-- <h3 class="title1">net area :</h3>
                                <span class="amount">615 SQ.FT</span> -->

                        </div>
                        <div class="pricingTable-signup">
                            <a href="javascript:void(0)" class="price-click">Click Here</a>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-3" data-aos="fade-right" data-aos-delay="300" data-aos-duration="1000">

                <div class="priceshadow">
                    <div class="pricingTable">
                        <div class="pricingTable-header">
                            <h3 class="title">2 BHK Apex</h3>
                        </div>
                        <div class="price-value">
                            <h3 class="title1">rera carpet area :</h3>
                            <span class="amount">685 SQ.FT</span>

                            <div class="line"></div>

                            <!-- <h3 class="title1">balcony area :</h3>
                                <span class="amount">26 SQ.FT</span>
                                <div class="line"></div> -->
                            <!-- <h3 class="title1">net area :</h3>
                                <span class="amount">711 SQ.FT</span> -->

                        </div>
                        <div class="pricingTable-signup">
                            <a href="javascript:void(0)" class="price-click">Click Here</a>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-3" data-aos="fade-right" data-aos-delay="600" data-aos-duration="1000">

                <div class="priceshadow">
                    <div class="pricingTable">
                        <div class="pricingTable-header">
                            <h3 class="title">3 BHK Eterna</h3>
                        </div>
                        <div class="price-value">
                            <h3 class="title1">rera carpet area :</h3>
                            <span class="amount">790 SQ.FT</span>

                            <div class="line"></div>
                            <!-- <h3 class="title1">balcony area :</h3>
                                <span class="amount">24 SQ.FT</span>
                                <div class="line"></div> -->
                            <!-- <h3 class="title1">net area :</h3>
                                <span class="amount">814 SQ.FT</span> -->

                        </div>
                        <div class="pricingTable-signup">
                            <a href="javascript:void(0)" class="price-click">Click Here</a>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-3" data-aos="fade-right" data-aos-delay="500" data-aos-duration="1000">

                <div class="priceshadow">
                    <div class="pricingTable">
                        <div class="pricingTable-header">
                            <h3 class="title">3 BHK Elite</h3>
                        </div>
                        <div class="price-value">
                            <h3 class="title1">rera carpet area :</h3>
                            <span class="amount">855 SQ.FT</span>

                            <div class="line"></div>
                            <!-- <h3 class="title1">balcony area :</h3>
                                <span class="amount">39 SQ.FT</span>
                                <div class="line"></div> -->
                            <!-- <h3 class="title1">net area :</h3>
                                <span class="amount">894 SQ.FT</span> -->

                        </div>
                        <div class="pricingTable-signup">
                            <a href="javascript:void(0)" class="price-click">Click Here</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</section>

<section id="location" class="sec-loaction">
    <div class="">
        <div class="container">
            <div class="section-head white clearfix">
            </div>
            <div class="row mr0">
                <div class="col-md-12">
                    <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                        <h2 class="m-b5">Location Advantage</h2>
                    </div>
                </div>
                <!-- Nav tabs -->
                <div class="tab-content">
                    <!-- ======================================== -->

                    <!-- <div role="tabpanel" class="tab-pane fade active in" id="tab360">
                            <div class="tab-content-wrap">

                               

                            </div>
                        </div> -->
                    <div class="col-md-6 pd0">

                        <!-- <div class="head-location">
                                <h2>Location Advantage</h2>
                            </div> -->
                        <div class="col-md-12" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">

                            <div id="accordion" class="panel-group">
                                <div class="panel">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a href="#panelBodyfour" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" aria-expanded="true">School</a>
                                        </h4>
                                    </div>
                                    <div id="panelBodyfour" class="panel-collapse collapse in" aria-expanded="false">
                                        <div class="panel-body">
                                            <ul class="loc-list">
                                                <li>Smt. Sunitidevi Singhania School - 5 min</li>
                                                <li>Smt. Sulochanadevi Singhania School - 5 min</li>
                                                <li>C.P. Goenka International School - 12 min</li>
                                                <li>Lodha World School - 9 min </li>
                                                <li>Orchid International School - 14 min</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a href="#panelBodyOne" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" aria-expanded="false">Connectivity</a>
                                        </h4>
                                    </div>
                                    <div id="panelBodyOne" class="panel-collapse collapse " aria-expanded="false">
                                        <div class="panel-body">
                                            <ul class="loc-list">
                                                <li> Cadbury Junction (Upcoming Metro Station) - 3 min</li>
                                                <li> Upcoming Metro Line 4 Majiwada Junction (Upcoming Metro Station) - 5 min </li>
                                                <li> Teenhath Naka (Upcoming Metro Station) - 7 min</li>
                                                <li> Thane Station - 10 min</li>
                                                <li> Manpada Junction – 11 min</li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a href="#panelBodyTwo" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" aria-expanded="false">Hospital</a>
                                        </h4>
                                    </div>
                                    <div id="panelBodyTwo" class="panel-collapse collapse" aria-expanded="false">
                                        <div class="panel-body">
                                            <ul class="loc-list">
                                                <li>Jupiter Hospital - 2 min </li>

                                                <li>Bethany Hospital - 10 min
                                                </li>
                                                <li>
                                                    Titan Hospital - 10 min</li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a href="#panelBodyThree" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" aria-expanded="false">Shopping</a>
                                        </h4>
                                    </div>
                                    <div id="panelBodyThree" class="panel-collapse collapse" aria-expanded="false">
                                        <div class="panel-body">
                                            <ul class="loc-list">
                                                <li>
                                                    Viviana Mall - 2 min</li>
                                                <li> R Mall (Thane) - 12min</li>
                                                <li>
                                                    D-Mart - 13 min </li>
                                                <li>
                                                    Hypercity - 17 min
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                    <div class="col-md-6">
                        <!-- <div class="head-location">
                                <h2>Project Location</h2>
                            </div> -->
                        <div class="col-md-12" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">

                            <!-- <div class="amenities-gallery mg-mb">
                                    <div class="overlayg"></div>
                                    <img src="images/loc-t.webp" alt="">
                                    <a href="images/loc-t.webp" data-fancybox="loc" data-caption="SPA">
                                        <div class="ami-overlay">
                                            <div class="d-flex">
                                                <h3>LOCATION MAP</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div> -->

                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d120564.48001886753!2d72.8879736!3d19.2109199!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b9d670602ea7%3A0xafcb44e0722bd307!2sRaymond%20Ten%20X%20Era!5e0!3m2!1sen!2sin!4v1701862922301!5m2!1sen!2sin"
                                width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


                        </div>
                    </div>

                </div>


            </div>

            <!-- <div class="col-md-12">
                    <a class="googlebtn"
                        href="https://www.google.com/maps/place/Kolte+Patil+Jai+Vijay/@19.1084871,72.8543345,15z/data=!4m5!3m4!1s0x0:0x817ad9a065d198c6!8m2!3d19.1084871!4d72.8543345"
                        title="" data-fancybox="google">
                        <img src="images/googlemaps.webp">
                        <span>Google Map</span>
                    </a>
                </div> -->

        </div>
    </div>
</section>

<!-- WELCOME SECTION START -->
<div id="amenities" class="abtslider-sec">
    <div class="container">

        <div class="section-head clearfix">
            <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                <!-- <small class="wt-small-title">Project Amenities</small> -->
                <h2 class="m-b5">Project Amenities</h2>
            </div>
            <div class="title-right-detail">

                <!-- Nav tabs -->
                <!-- <ul class="nav nav-tabs mytab ametab hidden-xs hidden-sm" role="tablist">

                        <li role="presentation" class="active">
                            <a href="#ametab" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">
                                Amenities
                            </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#spetab" aria-controls="profile" role="tab" data-toggle="tab"
                                aria-expanded="true">Specifications
                            </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#galltab" aria-controls="profile" role="tab" data-toggle="tab"
                                aria-expanded="true">Gallery
                            </a>
                        </li>
                        <li role="presentation" class="">
                        <a href="#videotab" aria-controls="profile" role="tab" data-toggle="tab"
                           aria-expanded="true">Video
                        </a>
                    </li>
                    </ul> -->

            </div>
        </div>


        <div class="row mr0 hidden-xs">

            <!-- Nav tabs -->
            <!--<ul class="nav nav-tabs mytab ametab visible-xs visible-sm" role="tablist">

                     <li role="presentation" class="active">
                        <a href="#ametab" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">
                            Amenities
                        </a>
                    </li> -->
            <!-- <li role="presentation" class="">
                        <a href="#spetab" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">Specifications

                        </a>
                    </li> -->
            <!-- <li role="presentation" class="">
                        <a href="#galltab" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">Gallery
                        </a>
                    </li> -->
            <!-- <li role="presentation" class="">
                    <a href="#videotab" aria-controls="profile" role="tab" data-toggle="tab"
                       aria-expanded="true">Video
                    </a>
                </li> --
                </ul> -->

            <!-- <h3 class="title">KEY OUTDOOR AMENITIES</h3> -->

            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/1.webp" alt="ame">
                        <p>Tennis Lawn</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/2.webp" alt="ame">
                        <p>Hammock Garden</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="2s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/3.webp" alt="ame">
                        <p>Senior Pavilion</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="2.5s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <!-- <i class="flatame-parliament"></i> -->
                        <img src="images/ame/4.webp" alt="ame">
                        <p>Yoga Pavilion</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="3s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/5.webp" alt="ame">
                        <p>Cricket Box</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="4s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/6.webp" alt="ame">
                        <p>Picnic Area</p>
                    </div>
                </div>
            </div>

            <!-- <h3 class="title">KEY OUTDOOR AMENITIES</h3> -->

            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/7.webp" alt="ame">
                        <p>Spa</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/8.webp" alt="ame">
                        <p>Minitheater</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="2s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/9.webp" alt="ame">
                        <p>Community Kitchen</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="2.5s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <!-- <i class="flatame-parliament"></i> -->
                        <img src="images/ame/10.webp" alt="ame">
                        <p>Gym & Pilates Studio</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="3s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/11.webp" alt="ame">
                        <p>Library & Reading Lounges</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="4s">
                <div class="amiwrap border-effect">
                    <div class="bo">
                        <img src="images/ame/12.webp" alt="ame">
                        <p>Pet Spa</p>
                    </div>
                </div>
            </div>

        </div>
        <div class="row mr0 visible-xs">

            <div class="owl-carousel owl-theme isoo-carousel">


                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/1.webp" alt="ame">
                            <p>Tennis Lawn</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/2.webp" alt="ame">
                            <p>Hammock Garden</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="2s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/3.webp" alt="ame">
                            <p>Senior Pavilion</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="2.5s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <!-- <i class="flatame-parliament"></i> -->
                            <img src="images/ame/4.webp" alt="ame">
                            <p>Yoga Pavilion</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="3s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/5.webp" alt="ame">
                            <p>Cricket Box</p>
                        </div>
                    </div>
                </div>

                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="4s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/6.webp" alt="ame">
                            <p>Picnic Area</p>
                        </div>
                    </div>
                </div>

                <!-- <h3 class="title">KEY OUTDOOR AMENITIES</h3> -->

                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/7.webp" alt="ame">
                            <p>Spa</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/8.webp" alt="ame">
                            <p>Minitheater</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="2s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/9.webp" alt="ame">
                            <p>Community Kitchen</p>
                        </div>
                    </div>
                </div>
                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="2.5s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <!-- <i class="flatame-parliament"></i> -->
                            <img src="images/ame/10.webp" alt="ame">
                            <p>Gym & Pilates Studio</p>
                        </div>
                    </div>
                </div>

                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="3s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/11.webp" alt="ame">
                            <p>Library & Reading Lounges</p>
                        </div>
                    </div>
                </div>

                <div class="item wow fadeInUp" data-wow-duration="1s" data-wow-delay="4s">
                    <div class="amiwrap border-effect">
                        <div class="bo">
                            <img src="images/ame/12.webp" alt="ame">
                            <p>Pet Spa</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- WELCOME  SECTION END -->

<div id="progallery" class="global-sec greybg">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                    <h2 class="m-b5">Gallery</h2>
                </div>
            </div>
            <div class="col-md-8">
                <div class="title-right-detail" style="padding-left:0">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs mytab ametab hidden-xs hidden-sm" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#galltab3" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Exterior
                                </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#galltab5" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Lifestyle
                                </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#galltab2" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Interior
                                </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#galltab4" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Amenities
                                </a>
                        </li>

                        <li role="presentation" class="">
                            <a href="#galltab1" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Floor Plan
                                </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row mr0">

            <!-- Nav tabs -->
            <ul class="nav nav-tabs mytab ametab visible-xs visible-sm" role="tablist">
                <li role="presentation" class="active">
                    <a href="#galltab3" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Exterior
                        </a>
                </li>
                <li role="presentation" class="">
                    <a href="#galltab5" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Lifestyle
                        </a>
                </li>
                <li role="presentation" class="">
                    <a href="#galltab2" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Interior
                        </a>
                </li>
                <li role="presentation" class="">
                    <a href="#galltab4" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Amenities
                        </a>
                </li>

                <li role="presentation" class="">
                    <a href="#galltab1" aria-controls="profile" role="tab" data-toggle="tab" aria-expanded="true">Floor Plan
                        </a>
                </li>
            </ul>


            <div class="tab-content">
                <!-- ======================================== -->

                <div role="tabpanel" class="tab-pane fade" id="galltab2">
                    <div class="tab-content-wrap">

                        <div class="col-md-12 pd0">

                            <div class="owl-carousel owl-theme gall-carousel">
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/01.webp" alt="">
                                        <a href="images/gallery/interior/01.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/02.webp" alt="">
                                        <a href="images/gallery/interior/02.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/03.webp" alt="">
                                        <a href="images/gallery/interior/03.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/04.webp" alt="">
                                        <a href="images/gallery/interior/04.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/05.webp" alt="">
                                        <a href="images/gallery/interior/05.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/06.webp" alt="">
                                        <a href="images/gallery/interior/06.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/07.webp" alt="">
                                        <a href="images/gallery/interior/07.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/08.webp" alt="">
                                        <a href="images/gallery/interior/08.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/09.webp" alt="">
                                        <a href="images/gallery/interior/09.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/10.webp" alt="">
                                        <a href="images/gallery/interior/10.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/11.webp" alt="">
                                        <a href="images/gallery/interior/11.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-1.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-1.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-2.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-2.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-3.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-3.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-4.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-4.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-5.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-5.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-6.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-6.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-7.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-7.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/interior/2bhk-8.webp" alt="">
                                        <a href="images/gallery/interior/2bhk-8.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div role="tabpanel" class="tab-pane fade" id="galltab5">
                    <div class="tab-content-wrap">

                        <div class="col-md-12 pd0">

                            <div class="owl-carousel owl-theme gall-carousel">
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/lifestyle/01.webp" alt="">
                                        <a href="images/gallery/lifestyle/01.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/lifestyle/02.webp" alt="">
                                        <a href="images/gallery/lifestyle/02.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/lifestyle/03.webp" alt="">
                                        <a href="images/gallery/lifestyle/03.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/lifestyle/04.webp" alt="">
                                        <a href="images/gallery/lifestyle/04.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/lifestyle/05.webp" alt="">
                                        <a href="images/gallery/lifestyle/05.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <!-- <div class="item">
                                        <div class="amenities-gallery mapb mg-mb">
                                            <div class="overlayg transparent"></div>
                                            <img src="images/gallery/lifestyle/06.webp" alt="">
                                            <a href="images/gallery/lifestyle/06.webp" data-fancybox="gall"
                                                data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                        <h3></h3>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="amenities-gallery mapb mg-mb">
                                            <div class="overlayg transparent"></div>
                                            <img src="images/gallery/lifestyle/07.webp" alt="">
                                            <a href="images/gallery/lifestyle/07.webp" data-fancybox="gall"
                                                data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                        <h3></h3>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="amenities-gallery mapb mg-mb">
                                            <div class="overlayg transparent"></div>
                                            <img src="images/gallery/lifestyle/08.webp" alt="">
                                            <a href="images/gallery/lifestyle/08.webp" data-fancybox="gall"
                                                data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                        <h3></h3>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="amenities-gallery mapb mg-mb">
                                            <div class="overlayg transparent"></div>
                                            <img src="images/gallery/lifestyle/09.webp" alt="">
                                            <a href="images/gallery/lifestyle/09.webp" data-fancybox="gall"
                                                data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                        <h3></h3>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div> -->

                            </div>
                        </div>

                    </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="galltab1">
                    <div class="tab-content-wrap">


                        <div class="col-md-12 pd0" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                            <div class="owl-carousel owl-theme floor-carousel">
                                <div class="item">
                                    <div class="amenities-gallery mg-mb floor-click">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/floor/11.webp" alt="" style="filter: blur(8px);
  -webkit-filter: blur(8px);">
                                        <!-- <a href="images/gallery/floor/11.webp" data-fancybox="floor" data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                       
                                                    </div>
                                                </div>
                                            </a> -->
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb floor-click">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/floor/12.webp" alt="" style="filter: blur(8px);
  -webkit-filter: blur(8px);">
                                        <!-- <a href="images/gallery/floor/12.webp" data-fancybox="floor" data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">

                                                    </div>
                                                </div>
                                            </a> -->
                                    </div>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>

                <div role="tabpanel" class="tab-pane fade active in" id="galltab3">
                    <div class="tab-content-wrap">


                        <div class="row mr0">
                            <div class="owl-carousel owl-theme gall-carousel">
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/01.webp" alt="">
                                        <a href="images/gallery/exterior/01.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/02.webp" alt="">
                                        <a href="images/gallery/exterior/02.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/03.webp" alt="">
                                        <a href="images/gallery/exterior/03.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/07.webp" alt="">
                                        <a href="images/gallery/exterior/07.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/08.webp" alt="">
                                        <a href="images/gallery/exterior/08.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/09.webp" alt="">
                                        <a href="images/gallery/exterior/09.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/10.webp" alt="">
                                        <a href="images/gallery/exterior/10.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/exterior/11.webp" alt="">
                                        <a href="images/gallery/exterior/11.webp" data-fancybox="iso" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!-- <h3></h3> -->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane fade" id="galltab4">
                    <div class="tab-content-wrap">


                        <div class="col-md-12 pd0">

                            <div class="owl-carousel owl-theme gall-carousel">
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/01.webp" alt="">
                                        <a href="images/gallery/club/01.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/02.webp" alt="">
                                        <a href="images/gallery/club/02.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/03.webp" alt="">
                                        <a href="images/gallery/club/03.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/04.webp" alt="">
                                        <a href="images/gallery/club/04.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/05.webp" alt="">
                                        <a href="images/gallery/club/05.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/06.webp" alt="">
                                        <a href="images/gallery/club/06.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/07.webp" alt="">
                                        <a href="images/gallery/club/07.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/08.webp" alt="">
                                        <a href="images/gallery/club/08.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <!-- <div class="item">
                                        <div class="amenities-gallery mapb mg-mb">
                                            <div class="overlayg transparent"></div>
                                            <img src="images/gallery/club/09.webp" alt="">
                                            <a href="images/gallery/club/09.webp" data-fancybox="gall" data-caption="">
                                                <div class="ami-overlay">
                                                    <div class="d-flex">
                                                        <h3></h3>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div> -->
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/10.webp" alt="">
                                        <a href="images/gallery/club/10.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/11.webp" alt="">
                                        <a href="images/gallery/club/11.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="amenities-gallery mapb mg-mb">
                                        <div class="overlayg transparent"></div>
                                        <img src="images/gallery/club/12.webp" alt="">
                                        <a href="images/gallery/club/12.webp" data-fancybox="gall" data-caption="">
                                            <div class="ami-overlay">
                                                <div class="d-flex">
                                                    <!--<h3></h3>-->
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>

            </div>

        </div>
    </div>
</div>


<section id="aboutus" class="sec-about">
    <div class="container">
        <div class="row mr0">
            <div class="col-md-12">

                <div class="section-head clearfix">
                    <div class="wt-tilte-main bdr-r-3 bdr-primary bdr-solid">
                        <!-- <small class="wt-small-title">ABOUT</small> -->
                        <span style="font-size: 20px;text-transform: uppercase;font-weight: bold;">About</span>
                        <h2 class="m-b5">Raymond Realty</h2>
                    </div>
                    <!-- <div class="title-right-detail">
                        <p></p>
                    </div> -->
                </div>


                <!--<h2 class="about-head hidden-xs" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
                    ABOUT<br>
                    KOLTE PATIL
                </h2>
                <h2 class="about-head visible-xs" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
                    ABOUT
                    KOLTE PATIL
                </h2>-->
                <!-- <p class="abtsubhead" data-aos="fade-up" data-aos-delay="250" data-aos-duration="1000">
                    Founded 3 Decades Ago And Guided By A Simple Yet Profound Philosophy, 'creation, Not Construction',
                    Kolte-Patil Developers Ltd. Is One Of The Foremost Real Estate Companies.
                </p> -->
            </div>
            <div class="col-md-12">
                <!-- <div class="col-md-6 pdm-0">
                    <div class="abouttxt border-d" data-aos="fade-down" data-aos-delay="300" data-aos-duration="1000">
                        <h2>
                            <span class='numscroller' data-min='0' data-max='3' data-delay='1'
                                  data-increment='1'>3</span> Decades<br>
                            Of
                        </h2>
                        <p>
                            Excellence
                        </p>
                    </div>
                </div>
                <div class="col-md-6 pdm-0">
                    <div class="abouttxt border-d" data-aos="fade-down" data-aos-delay="350" data-aos-duration="1000">
                        <h2>
                            <span class='numscroller' data-min='0' data-max='20' data-delay='1'
                                  data-increment='1'>20</span>+<br>
                            Million
                        </h2>
                        <p>
                            SQ. FT. Delivered
                        </p>
                    </div>
                </div>
                <div class="col-md-6 pdm-0">
                    <div class="abouttxt border-m" data-aos="fade-up" data-aos-delay="400" data-aos-duration="1000">
                        <h2>
                            <span class='numscroller' data-min='0' data-max='70' data-delay='1'
                                  data-increment='1'>70</span>+ Sucessful<br>
                            Projects
                        </h2>
                        <p>
                            Across Pune, Mumbai & Bengaluru
                        </p>
                    </div>
                </div>
                <div class="col-md-6 pdm-0">
                    <div class="abouttxt" data-aos="fade-up" data-aos-delay="450" data-aos-duration="1000">
                        <h2>
                            Largest<br>
                            Developer
                        </h2>
                        <p>
                            In Pune
                        </p>
                    </div>
                </div> -->
                <p class="abtsubhead" data-aos="fade-up" data-aos-delay="250" data-aos-duration="1000" style="text-align: justify;">
                    Since inception in 1925, Raymond has been a renowned brand, synonymous with Trust, Quality and Excellence. We are known to raise the bar in every industry domain we foray into fashion, Lifestyle, Technology or Real Estate. Raymond Realty moves forward,
                    building upon the group’s rich legacy of setting new benchmarks with customer centricity at the core. Our focus is clear and absolute to Go Beyond real estate conventions. To introduce a new standard of living that pushes the envelope
                    on every aspect construction quality, design aesthetic and comfort feasibility. It is this conviction that makes a Raymond residence your dream abode. We bring you elegant modern spaces, pleasant ambience and a range of exclusive amenities
                    making it a living experience unlike any other. And to ensure this, we always Go Beyond ourselves.
                </p>
            </div>
        </div>
    </div>
</section>

<section id="contactus" class="sec-contact">
    <div class="container">
        <div class="row mr0">
            <div class="col-md-12 pd0">

                <div class="main-contactwrap">
                    <div class="contact-overlay">

                        <div class="section-head clearfix white">
                            <div class="">
                                <h2 class="head-cointact" style="text-align: center;">Get In Touch With Us</h2>
                                <!-- <h2 class="m-b5"></h2> -->
                            </div>
                            <!-- <div class="title-right-detail">
                                    <p></p>
                                </div> -->
                        </div>


                        <div>
                            <p class="form-txt">Please Enter Your Details To Know More About Raymond TenX Era

                            </p>

                            <form id="contact-form" action="thank-you.php" name="contact-form" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('contact-form');">
                                <div class="form-group col-md-4">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                        </div>
                                        <input type="text" class="form-control" name="fname" placeholder="Name">
                                        <input type="hidden" id="source" name="source" value="Contact Form">
                                    </div>
                                    <label for="fname" class="error"></label>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                        </div>
                                        <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                                    </div>
                                    <label for="mobile" class="error"></label>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                        </div>
                                        <input type="email" class="form-control" name="email" placeholder="Email">
                                    </div>
                                    <label for="email" class="error"></label>
                                </div>
                                <div class="col-md-12">
                                    <div class="check-input">
                                        <div class="row">
                                            <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox" style="width:3% !important">
                                            <p class="form-terms">
                                                By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                            </p>
                                        </div>
                                    </div>
                                    <label for="termcheckbox" class="error"></label>
                                </div>
                                <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                            </form>

                            <p class="contact-add">
                                Sales Gallery : The Mill, JekeGram, Pokharan Rd Number 1, Thane West, Maharashtra 400606
                            </p>

                            <p class="form-calltxt">
                                Call: <a href="tel:02268364141">02268364141</a> / +91 22-68685500
                            </p>
                            <p class="form-calltxt">
                                Email : <a href="mailto:realty@raymond.in">realty@raymond.in</a>
                            </p>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
</section>

<!-- <footer class="sec-footer">
        <div class="container">
            <img class="footerlogo" src="images/kolte-patil.webp">
            <p class="copy-txt">
                COPYRIGHT &copy; 2021. lorem. ALL RIGHTS RESERVED.
            </p>
            <p class="rera-txt">
                The project has been registered under MahaRERA registration number P51XXXXXXXX and are available on the
                website https://maharera.mahaonline.gov.in Under Registered Projects.
            </p>
        </div>
    </footer> -->
<div class="sec-disc">
    <div class="container">
        <!-- <div class="col-md-12 qr">
                <div class=" col-md-4 qr-box">
                    <img src="images/qr1.PNG" alt="qrcode">
                    <p>TEN X ERA</p>
                    <p>Raymond Realty Tower A</p>
                </div>
                <div class=" col-md-4 qr-box">
                    <img src="images/qr2.PNG" alt="qrcode">
                    <p>TEN X ERA</p>
                    <p>Raymond Realty Tower B</p>
                </div>
                <div class=" col-md-4 qr-box">
                    <img src="images/qr3.png" alt="qrcode">
                    <p>TEN X ERA</p>
                    <p>Raymond Realty Tower C</p>
                </div>
                <div class="col-md-4 qr-box">
                    <img src="images/qr2.PNG" alt="qrcode">
                    <p>TEN X ERA <br>Raymond Realty Tower C </p>
                </div>

            </div> -->
        <!-- ********************** Carousel Start ******************************* -->

        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel owl-theme qr-carousel">
                    <div class="item">
                        <div class="qr-box">
                            <img src="images/qr1.PNG" alt="qrcode">
                            <p>TEN X ERA</p>
                            <p>Raymond Realty Tower A</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="qr-box">
                            <img src="images/qr2.PNG" alt="qrcode">
                            <p>TEN X ERA</p>
                            <p>Raymond Realty Tower B</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="qr-box">
                            <img src="images/qr3.png" alt="qrcode">
                            <p>TEN X ERA</p>
                            <p>Raymond Realty Tower C</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- ********************** Carousel End ******************************* -->
        <div class="footerwrap">
            <!-- <img class="reralogo" src="images/rera.webp"> -->
            <p>
                Disclaimer: All image/s are strictly for illustrative and representational purposes.TEN X ERA Raymond Realty | Tower A TEN X ERA Raymond Realty | Tower B, TEN X ERA Raymond Realty | Tower C, TEN X ERA Raymond Realty larger project of TEN X ERA Raymond
                Realty bearing MAHARERA registration number P51700049592 | P51700049520 | PS1700053528. Visit the MahaRERA website viz https://maharera.mahaonline.gov.in/. Other terms & conditions apply

            </p>
        </div>
        <!-- <div class="footer-logo">
                <img src="images/logo-1.jpg" alt="">
            </div> -->
        <p class="copy-txt text-center">
            &copy; 2023 Raymond Realty. ALL RIGHTS RESERVED. | Powered By <a href="https://realatte.com/" target="_blank" class="realatte">Realatte</a>
        </p>

        <div class="row" style="display: none;">
            <div class="col-md-12">
                <div class="modal-body" style="padding:0px">
                    <h3 class="tc-heading" style="font-size: 14px;">Terms and Conditions :</h3>
                    <ul class="dis">
                        <li>
                            The home fest will be commencing from 14th June 2024 to 30th June, 2024.
                        </li>
                        <li>
                            Any booking done after 30th June will not be considered for the following offers.
                        </li>
                        <li>
                            The following offers are applicable for Ten X Era: The purchaser will be entitled to any 1 offer out of following 3 offers.
                        </li>
                    </ul>
                    <!-- <p>The home fest will be commencing from 14th June 2024 to 23rd June, 2024.</p>
                                        <p>Any booking done after 23rd June will not be considered for the following offers.</p>
                                        <p>The following offers are applicable for Ten X Era: The purchaser will be entitled to any 1 offer out of following 3 offers.</p> -->
                    <ol class="disclaimerPoints">
                        <li>
                            Subvention Scheme: This offer is applicable for Tower A, B & C of TEN X Era till January 2025.
                        </li>
                        <li>
                            Rent Back: Rent amount will be calculated after successful registration of the unit. The rent amount may vary on the basis of unit and Project. The decision of the amount of rent calculated by the Prompter shall be final and binding upon the purchasers.
                            The rent shall be paid for the period 12 months from the date of registration of the apartment.
                        </li>
                        <li>
                            International Trip Voucher: Trip voucher worth Rs.4 Lakh will be given on successful booking and registration or else can be availed as upfront discount.
                        </li>
                    </ol>
                    <p style="margin-top:20px">List of other offers for Homefest (14th June 2024 to 30th June, 2024)</p>
                    <ol class="disclaimerPoints">
                        <li>
                            Zero Stamp Duty.
                        </li>
                        <li>
                            No Floor rise. (Not applicable for Ten X Era)
                        </li>
                        <li>
                            Spot offer: upto Rs.1 Lakh.
                        </li>
                        <li>
                            Spin the wheel: All the bookings made under home fest campaign are eligible to spin the lucky draw wheel to avail an additional discount of upto Rs.50,000/-
                        </li>
                        <li>
                            Raymond Home Furnishing: Furnishing gift worth of Rs.30,000/- will be given.
                        </li>
                    </ol>
                </div>
            </div>
        </div>

    </div>
</div>


<!-- ================ Road Block ==================== -->
<!--<div class="modal fade in" tabindex="-1" role="dialog" id="roadblock" data-backdrop="static"
     data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <img class="roadblockimg" src="#" alt="Life Republic Offer">
                <a href="#" target="_blank" class="roadblocklink">KNOW MORE</a>
            </div>
        </div>
    </div>
</div>-->

<div id="pageloader">
    <div class="loading-wrap">
        <img src="images/loading.gif" alt="Raymond">
    </div>
</div>

<div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-md hidden-lg hidden-sm">
    <div class="container">
        <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
            <a href="tel:02268364141" class="fix-link callme">
                    <i class="fa fa-phone f-icon" aria-hidden="true"></i>
                    CALL NOW
                </a>
        </div>
        <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
            <!-- <button class="btn fix-link i-am"><i class="fa fa-envelope"></i> I'M INTERESTED</button> -->
            <button class="btn btn-danger E-brochure down brochure-mob vissible-xs"><i class="fa fa-download"></i>
                    E-Brochure</button>
        </div>
    </div>
</div>


<!-- ================ main pop ==================== -->
<div class="modal fade in" tabindex="-1" role="dialog" id="main-modal" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/logo-1.jpg" alt="Life Republic icon">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                <!-- <h3>Express Your Interest</h3> -->
                <!-- <p>Please Enter Your Details To Know More About Raymond TenX Era </p> -->
                <p class="highlight-heading">2 & 3 BED HOMES STARTING AT ₹ 1.61 CR. (ALL INCL)</p>
                <form id="main-popup" action="thank-you.php" name="main-popup" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('main-popup');">
                    <div class="form-group col-md-6">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-user form-ico" aria-hidden="true"></i>
                            </div>
                            <input id="mainpopup-fname" type="text" class="form-control" name="fname" placeholder="Name">
                            <input type="hidden" name="source" value="Main PopUp">
                        </div>
                        <label for="mainpopup-fname" class="error"></label>
                    </div>
                    <div class="form-group col-md-6">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                            </div>
                            <input id="mainpopup-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                        </div>
                        <label for="mainpopup-mobile" class="error"></label>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input id="mainpopup-email" type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="mainpopup-email" class="error"></label>
                    </div>
                    <div class="col-md-12">
                        <div class="check-input">
                            <div class="row">
                                <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                <p class="form-terms">
                                    By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                </p>
                            </div>
                        </div>
                        <label for="termcheckbox" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- ============================================= -->

<!-- ================ Price PopUp ==================== -->
<div class="modal fade in" tabindex="-1" role="dialog" id="pricepop" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/logo-1.jpg" alt="Life Republic icon2">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                <h3>Price</h3>
                <p>Please Enter Your Details To Know More About Raymond TenX Era </p>
                <form id="price-popup" action="thank-you.php" name="price-popup" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('price-popup');">
                    <div class="row mr0">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="pricepopup-fname" type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Price PopUp">
                            </div>
                            <label for="pricepopup-fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="pricepopup-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="pricepopup-mobile" class="error"></label>
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input id="pricepopup-email" type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="pricepopup-email" class="error"></label>
                    </div>
                    <div class="col-md-12">
                        <div class="check-input">
                            <div class="row">
                                <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                <p class="form-terms">
                                    By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                </p>
                            </div>
                        </div>
                        <label for="termcheckbox" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- ============================================= -->

<div class="wave-holder sonar-wave hidden-xs"></div>
<button class="btn btn-danger interested hidden-xs">I'M Interested</button>

<!-- ================ I AM ==================== -->
<div class="modal fade in" tabindex="-1" role="dialog" id="interested" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/logo-1.jpg" alt="Life Republic icon2">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                <h3>Express Your Interest</h3>
                <p>Please Enter Your Details To Know More About Raymond TenX Era </p>
                <form id="enquire-now" action="thank-you.php" name="enquire-now" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('enquire-now');">
                    <div class="row mr0">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-fname" type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Enquire Now">
                            </div>
                            <label for="enquirenow-fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="enquirenow-mobile" class="error"></label>
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input id="enquirenow-email" type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="enquirenow-email" class="error"></label>
                    </div>
                    <div class="col-md-12">
                        <div class="check-input">
                            <div class="row">
                                <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                <p class="form-terms">
                                    By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                </p>
                            </div>
                        </div>
                        <label for="termcheckbox" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- ============================================= -->


<!-- ****************************************** Brochure Start ********************************** -->

<div class="wave-holder sonar-wave-left hidden-xs"></div>
<button class="btn btn-danger brochure E-brochure down hidden-xs">Download Brochure</button>
<!-- <button class="btn btn-danger brochure vissible-xs">Download Brochure</button> -->
<a href="./images/Ten_X_Era_Brochure.pdf" id="download-file" download></a>


<div class="modal fade in" tabindex="-1" role="dialog" id="brochure-model" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/logo-1.jpg" alt="Life Republic icon2">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                <h3>Download Brochure</h3>
                <p>Please Enter Your Details To Know More About Raymond TenX Era </p>
                <form id="brochureDownloadForm" action="thank-you.php" name="brochureDownloadForm" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('brochureDownloadForm');">
                    <div class="row mr0">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-fname" type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Brochure">
                            </div>
                            <label for="enquirenow-fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="enquirenow-mobile" class="error"></label>
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input id="enquirenow-email" type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="enquirenow-email" class="error"></label>
                    </div>
                    <div class="col-md-12">
                        <div class="check-input">
                            <div class="row">
                                <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                <p class="form-terms">
                                    By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                </p>
                            </div>
                        </div>
                        <label for="termcheckbox" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>


<!-- ****************************************** Brochure End ********************************** -->


<!-- ================ floor plan ==================== -->
<div class="modal fade in" tabindex="-1" role="dialog" id="floorplan" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/logo-1.jpg" alt="Life Republic icon2">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                <h3>Floor Plan</h3>
                <p>Please Enter Your Details To Know More About Raymond TenX Era </p>
                <form id="floor-now" action="thank-you.php" name="floor-now" method="POST" novalidate="novalidate" onsubmit="return save_landing_pageinfo('floor-now');">
                    <div class="row mr0">
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-fname" type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Floor Plan">
                            </div>
                            <label for="enquirenow-fname" class="error"></label>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-mobile form-ico" aria-hidden="true"></i>
                                </div>
                                <input id="enquirenow-mobile" type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="enquirenow-mobile" class="error"></label>
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                            </div>
                            <input id="enquirenow-email" type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                        <label for="enquirenow-email" class="error"></label>
                    </div>
                    <div class="col-md-12">
                        <div class="check-input">
                            <div class="row">
                                <input id="" required type="checkbox" class="form-checkbox" name="termcheckbox">
                                <p class="form-terms">
                                    By submitting an enquiry, I authorize Raymond Realty to contact me via Call, SMS, WhatsApp, Emailer or any other relevant medium.
                                </p>
                            </div>
                        </div>
                        <label for="termcheckbox" class="error"></label>
                    </div>
                    <button type="submit" class="btn btn-default popup-btn">SUBMIT</button>
                </form>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- ============================================= -->



<!-- Footer Link -->
<!-- Optional JavaScript -->
<script src="js/jquery.min.js"></script>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>-->


<script src="js/plugin.min.js"></script>
<script src="js/cookie.js"></script>
<script src="js/url-tracking.js"></script>
<script src="js/facebook-conversion.js"></script>
<!--<script src="js/mobilevalidate.js"></script>-->
<script src="js/custome.js"></script>
<script src="js/counter.js"></script>
<script src="js/parallax.min.js"></script>
<script>
    jQuery(document).ready(function($) {
        Delete_Cookie('formfilled');

        $(".E-brochure").click(function() {
            $('#brochure-model').modal('show');
        });


    });
</script>
<!-- ========== -->

<script src="js/tilt.jquery.js"></script>

<!--<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>-->
<script src="slick/slick.js"></script>

<script>
    // Mian PopUp
    if (!Get_Cookie('popout')) {
        $(window).load(function() {
            // var width = $(window).width();
            // if(width >= 767){
            setTimeout(function() {
                $('#main-modal').modal('show');
            }, 1000);
            // }
        });
    }
    $('.modal .close').click(function() {
        Set_Cookie('popout', 'it works', '', '/', '', '');
    });
</script>


<script>
    var lastScrollTop = 0;
    // element should be replaced with the actual target element on which you have applied scroll, use window in case of no target element.
    window.addEventListener("scroll", function() {
        // or window.addEventListener("scroll"....
        var st = window.pageYOffset || document.documentElement.scrollTop;
        if (st > lastScrollTop) {
            //alert('scroll down');
            document.getElementById("hide-menu").style.top = "-70px";
        } else {
            //alert('scroll up');
            document.getElementById("hide-menu").style.top = "0px";
        }
        lastScrollTop = st <= 0 ? 0 : st; // For Mobile or negative scrolling
    }, false);
</script>
<script>
    $('.open-menu').click(function() {
        document.getElementById("myNav").style.right = "0";
    });
    $('.close-menu').click(function() {
        document.getElementById("myNav").style.right = "-100%";
    });
</script>

<script>
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        if (!$('#' + elm + ' input[name="termcheckbox"]').is(":checked")) {
            event.preventDefault();
            $('#myPara').text("Select Checkbox");
            return false;
        }


        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }
        if (elm == 'main-popup') {
            emailid = "";
        } else {
            var atpos = emailid.indexOf("@");
            var dotpos = emailid.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                return false;
            }
        }
        if (message == undefined) {
            message = "";
        }

        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            if (elm == 'brochureDownloadForm') {
                document.getElementById('download-file').click();
            }
            return true;
        }
        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
</script>

<!-- ******************************************* Owl Carousel Start ***************************** -->

<script>
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive: {
            0: {
                items: 2,
                nav: false
            },
            600: {
                items: 3,
                nav: false
            },
            1000: {
                items: 3,
                nav: true,
                loop: false
            }
        }
    });
    $('.owl-offer').owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 4
            }
        }
    })
</script>

<!-- ******************************************* Owl Carousel End ***************************** -->

</body>

</html>